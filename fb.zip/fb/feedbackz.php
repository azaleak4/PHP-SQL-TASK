<?php

$BdBGColor = "#f4f4f4";
$BDColor = "#000000";
$FBGColor = "#ffff";
$BTBGB4Color = "#8cdded";
$BTBGFTColor = "#76bfde";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    
    <style>
        body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: <?php echo $BdBGColor; ?>;
    color: <?php echo $BDColor; ?>;
}

/* Center the form */
form {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background-color: <?php echo $FBGColor; ?>;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Style form elements */
form h1 {
    text-align: center;
    margin-bottom: 20px;
    color: #444;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 8px;
}

input[type="text"],
input[type="email"],
textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    font-size: 16px;
}

textarea {
    resize: none;
}

button {
    width: 100%;
    padding: 10px;
    background-color: <?php echo $BTBGB4Color; ?>;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background-color: <?php echo $BTBGFTColor; ?>;
}

        </style>

</head>
<body>
    <h1>Feedback Form</h1>
    <form action="submit_feedback.php" method="POST">
        <label for="username">Name:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="phone">Phone (optional):</label>
        <input type="text" id="phone" name="phone"><br>

        <label for="feedback">Feedback:</label><br>
        <textarea id="feedback" name="feedback_text" rows="5" cols="30" required></textarea><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>