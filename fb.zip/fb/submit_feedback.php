<?php

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "feedbackz_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$user = $_POST['username'];
$email = $_POST['email'];
$phone = isset($_POST['phone']) ? $_POST['phone'] : null;
$feedback_text = $_POST['feedback_text'];

$sql = "INSERT INTO feedback (username, email, phone, feedback_text) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $user, $email, $phone, $feedback_text);

if ($stmt->execute()) {
    echo "Thank you for your feedback!";
} else {
    echo "Error: " . $stmt->error;
}


$stmt->close();
$conn->close();
?>
